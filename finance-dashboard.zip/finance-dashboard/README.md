# Finance Dashboard — Projeto gerado
Este arquivo ZIP contém um projeto fullstack mínimo (frontend + backend).
Para rodar localmente:
- Backend: cd backend && npm install && cp .env.example .env (ajuste MONGO_URI) && npm run dev
- Frontend: cd frontend && npm install && npm run dev
Acesse frontend em http://localhost:5173 e backend em http://localhost:4000
